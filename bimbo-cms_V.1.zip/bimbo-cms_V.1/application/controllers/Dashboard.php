<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * This controller can be accessed 
 * for all logged in users
 */
class Dashboard extends CI_Controller {	


	public function index()
	{
		$data['title'] = "Dashboard"; 
		$data['role'] = "BIMBO ADMIN";

		$this->load->view("view_admin/header", $data);
		$this->load->view("dashboard");
	}

}