<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class adminController extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->dashboard();
	}

	// === fungsi link ===

	public function dashboard(){
		$data['title'] = "Dashboard"; 
		$data['role'] = "BIMBO ADMIN";

		$this->load->view("view_admin/header", $data);
		$this->load->view("dashboard");
	}

	public function bannerConfig(){
		$data['title'] = "Banner Configuration";
		$data['role'] = "BIMBO ADMIN";

		$this->load->view("view_admin/header", $data); 
		$this->load->view("view_admin/view_bannerconfig", $data);
	}
	
	public function calendarPage(){
		$data['title'] = "Calendar Page"; 
		$data['role'] = "BIMBO ADMIN";

		$this->load->view("view_admin/header", $data);
		$this->load->view("view_admin/view_calendarpage", $data);
	}

	public function adminGallery(){
		$data['title'] = "Admin Gallery";
		$data['role'] = "BIMBO ADMIN";

		$this->load->view("view_admin/header", $data); 
		$this->load->view("view_admin/view_admingallery", $data);
	}
}