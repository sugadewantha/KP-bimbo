<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class masterController extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->home();
	}

	// === fungsi link ===

	public function home(){
		$data['title'] = "Home Page"; 
	
		$this->load->view("view_home", $data);
	}

	function activity(){ 
		$data['title'] = "Activity Page"; 
		$this->load->view("view_activity", $data);
	}

	function gallery(){ 
		$data['title'] = "Gallery Page"; 
		$this->load->view("view_gallery", $data);
	}

	function about(){ 
		$data['title'] = "About Page"; 
		$this->load->view("view_about", $data);
	}

	function contact(){ 
		$data['title'] = "Contact Page"; 
		$this->load->view("view_contact", $data);
	}

	function registration(){ 
		$data['title'] = "Registration Page"; 
		$this->load->view("view_registration", $data);
	}	

	// CRUD
	function getValues(){
		$data['title'] = "DATABASES! "; 
		$this->load->model("get_db");

		$data['results'] = $this->get_db->getAll();

		$this->load->view("view_db", $data);

	}

	function insertValues(){
		$this->load->model("get_db");

		$newRow = array(
			array (
			"name" => "nasrillah"
			 ),
			array (
			"name" => "pratiwi"
			 )

		);

		$this->get_db->insert2($newRow);
		echo "it has been added";

	}

	function user(){ 
		$data['title'] = "user Page"; 
		$this->load->view("view_user", $data);
	}
	
	function admin(){ 
		$data['title'] = "admin Page"; 
		$this->load->view("view_admin", $data);
	}
}