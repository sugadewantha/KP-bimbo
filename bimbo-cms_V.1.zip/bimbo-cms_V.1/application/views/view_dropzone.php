<html>
<head>
<link href="<?php echo base_url('assets/css/dropzone/dropzone.css'); ?>" type="text/css" rel="stylesheet" />
<script src="<?php echo base_url('assets/js/dropzone/dropzone.min.js'); ?>" type="text/javascript"></script>
</head>
<body>
<h1>File Upload using dropzone.js and Codeigniter - arjun.net.in</h1>
<!-- <form action="<?php echo site_url('index.php/dropzone/upload'); ?>" class="dropzone"  > -->
<form action="<?php echo base_url('index.php/dropzone/upload') ?>" class="dropzone">
</form>
</body>
</html>
- See more at: https://arjunphp.com/drag-drop-file-upload-dropzone-js-codeigniter/#sthash.LWVJdrIq.dpuf