<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $title; ?></title>
	<meta charset="utf-8">
	<!-- Responsive Metatag -->
 	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
 	<!-- icon  -->
	<link rel="shortcut icon" href="<?php echo base_url('assets/images/bimbo-icon.png'); ?>" type="image/x-icon">
	<!-- style -->
	<link href="<?php echo base_url('assets/css/bootstrap/bootstrap.min.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/style.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/lightbox.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/responsive.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/animate.min.css'); ?>" rel="stylesheet" type="text/css" >
	<link href="<?php echo base_url('assets/css/uikit/uikit.css'); ?>" rel="stylesheet" type="text/css" >

</head>
<body>
<!-- WRAP EM ALL -->

	<!-- HEADER HERE -->
	<?php $this->load->view('header'); ?>
	<!-- END HEADER BRO -->	

    <!--START HOME SLIDER -->
    <section id="home">
      <!-- Carousel -->
      <div id="main-slide" class="carousel slide bnr-post" data-ride="carousel">

        <!-- Indicators -->
        <ol class="carousel-indicators">
          <li data-target="#main-slide" data-slide-to="0" class="active"></li>
          <li data-target="#main-slide" data-slide-to="1"></li>
          <li data-target="#main-slide" data-slide-to="2"></li>
        </ol>
        <!--/ Indicators end-->

        <!-- Carousel inner -->
        <div class="carousel-inner">
          <div class="item active">
            
            <img class="img-responsive" src="<?php echo base_url('assets/images/slider/banner-1.png')?>" alt="slider">
            <div class="slider-content">
              <div class="col-md-12 text-center">
                <h2 class="animated2">
                  <span>Welcome to <strong>BIMBO</strong></span>
              </h2>
                <h3 class="animated3">
               <span>Bimbingan Belajar Online Terpadu</span>
           </h3>
              
              </div>
            </div>
          </div>
          <!--/ Carousel item end -->
          <div class="item">
            <img class="img-responsive" src="<?php echo base_url('assets/images/slider/banner-2.png')?>" alt="slider">
            <div class="slider-content">
              <div class="col-md-12 text-center">
                <h2 class="animated4">
                <!-- <span><strong>Margo</strong> for the highest</span> -->
            </h2>
                <h3 class="animated5">
               <!-- <span>The Key of your Success</span> -->
           </h3>
                <!-- <p class="animated6"><a href="#" class="slider btn btn-system btn-large">Buy Now</a></p> -->
              </div>
            </div>
          </div>
          <!--/ Carousel item end -->
          <div class="item">
            <img class="img-responsive" src="<?php echo base_url('assets/images/slider/banner-3.png')?>" alt="slider">
            <div class="slider-content">
              <div class="col-md-12 text-center">
                <h2 class="animated7 white">
                <span>The way of <strong>Success</strong></span>
            </h2>
                <h3 class="animated8 white">
               <span>Why you are waiting</span>
           </h3>
                <div class="">
                 <!--  <a class="animated4 slider btn btn-system btn-large btn-min-block" href="#">Get Now</a><a class="animated4 slider btn btn-default btn-min-block" href="#">Live Demo</a> -->
                </div>
              </div>
            </div>
          </div>
          <!--/ Carousel item end -->
        </div>
        <!-- Carousel inner end-->

        <!-- Controls -->
        <a class="left carousel-control" href="#main-slide" data-slide="prev">
          <span><i class="fa fa-angle-left"></i></span>
        </a>
        <a class="right carousel-control" href="#main-slide" data-slide="next">
          <span><i class="fa fa-angle-right"></i></span>
        </a>
      </div>
      <!-- /carousel -->
    </section>


    <!-- <section id="home-slider">
        <div class="container">
            <div class="row">
                <div class="main-slider">
                    <div class="slide-text">
                        <h1>We Are Creative Nerds</h1>
                        <p>Boudin doner frankfurter pig. Cow shank bresaola pork loin tri-tip tongue venison pork belly meatloaf short loin landjaeger biltong beef ribs shankle chicken andouille.</p>
                        <a href="#" class="btn btn-common">SIGN UP</a>
                    </div>
                    <img src="<?php echo base_url('assets/images/pic/home/slider/hill.png')?>" class="slider-hill" alt="slider image">
                    <img src="<?php echo base_url('assets/images/pic/home/slider/house.png')?>" class="slider-house" alt="slider image">
                    <img src="<?php echo base_url('assets/images/pic/home/slider/sun.png')?>" class="slider-sun" alt="slider image">
                    <img src="<?php echo base_url('assets/images/pic/home/slider/birds1.png')?>" class="slider-birds1" alt="slider image">
                    <img src="<?php echo base_url('assets/images/pic/home/slider/birds2.png')?>" class="slider-birds2" alt="slider image">
                </div>
            </div>
        </div>
        <div class="preloader"><i class="fa fa-sun-o fa-spin"></i></div>
    </section> -->
    <!--END HOME SLIDER-->

    <section id="services">
        <div class="container">
            <div class="row">
                <div class="col-sm-4 text-center padding wow fadeIn" data-wow-duration="1000ms" data-wow-delay="300ms">
                    <div class="single-service">
                        <div class="wow scaleIn" data-wow-duration="500ms" data-wow-delay="300ms">
                            <img src="<?php echo base_url('assets/images/pic/home/icon1.png')?>" alt="">
                        </div>
                        <h2>Smart Education</h2>
                        <p>Ground round tenderloin flank shank ribeye. Hamkevin meatball swine. Cow shankle beef sirloin chicken ground round.</p>
                    </div>
                </div>
                <div class="col-sm-4 text-center padding wow fadeIn" data-wow-duration="1000ms" data-wow-delay="600ms">
                    <div class="single-service">
                        <div class="wow scaleIn" data-wow-duration="500ms" data-wow-delay="600ms">
                            <img src="<?php echo base_url('assets/images/pic/home/icon2.png')?>" alt="">
                        </div>
                        <h2>Based High Technology</h2>
                        <p>Hamburger ribeye drumstick turkey, strip steak sausage ground round shank pastrami beef brisket pancetta venison.</p>
                    </div>
                </div>
                <div class="col-sm-4 text-center padding wow fadeIn" data-wow-duration="1000ms" data-wow-delay="900ms">
                    <div class="single-service">
                        <div class="wow scaleIn" data-wow-duration="500ms" data-wow-delay="900ms">
                            <img src="<?php echo base_url('assets/images/pic/home/icon3.png')?>" alt="">
                        </div>
                        <h2>Practice Learning</h2>
                        <p>Venison tongue, salami corned beef ball tip meatloaf bacon. Fatback pork belly bresaola tenderloin bone pork kevin shankle.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/#services-->

    <section id="action" class="responsive">
        <div class="vertical-center">
             <div class="container">
                <div class="row">
                    <div class="action take-tour">
                        <div class="col-sm-7 wow fadeInLeft" data-wow-duration="500ms" data-wow-delay="300ms">
                            <h1 class="title">Bimbingan Belajar Online</h1>
                            <p>A responsive, retina-ready &amp; wide multipurpose template.</p>
                        </div>
                        <div class="col-sm-5 text-center wow fadeInRight" data-wow-duration="500ms" data-wow-delay="300ms">
                            <div class="tour-button">
                                <a href="#" class="btn btn-common">TAKE THE TOUR</a>
                             </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
   </section>
    <!--/#action-->

    <section id="features">
        <div class="container">
            <div class="row">
                <div class="single-features">
                    <div class="col-sm-5 wow fadeInLeft" data-wow-duration="500ms" data-wow-delay="300ms">
                        <img src="<?php echo base_url('assets/images/pic/home/image1.png')?>" class="img-responsive" alt="">
                    </div>
                    <div class="col-sm-6 wow fadeInRight" data-wow-duration="500ms" data-wow-delay="300ms">
                        <h2>Experienced Education</h2>
                        <P>Pork belly leberkas cow short ribs capicola pork loin. Doner fatback frankfurter jerky meatball pastrami bacon tail sausage. Turkey fatback ball tip, tri-tip tenderloin drumstick salami strip steak.</P>
                    </div>
                </div>
                <div class="single-features">
                    <div class="col-sm-6 col-sm-offset-1 align-right wow fadeInLeft" data-wow-duration="500ms" data-wow-delay="300ms">
                        <h2>Practice Learning</h2>
                        <P>Mollit eiusmod id chuck turducken laboris meatloaf pork loin tenderloin swine. Pancetta excepteur fugiat strip steak tri-tip. Swine salami eiusmod sint, ex id venison non. Fugiat ea jowl cillum meatloaf.</P>
                    </div>
                    <div class="col-sm-5 wow fadeInRight" data-wow-duration="500ms" data-wow-delay="300ms">
                        <img src="<?php echo base_url('assets/images/pic/home/image2.png')?>" class="img-responsive" alt="">
                    </div>
                </div>
                <div class="single-features">
                    <div class="col-sm-5 wow fadeInLeft" data-wow-duration="500ms" data-wow-delay="300ms">
                        <img src="<?php echo base_url('assets/images/pic/home/image3.png')?>" class="img-responsive" alt="">
                    </div>
                    <div class="col-sm-6 wow fadeInRight" data-wow-duration="500ms" data-wow-delay="300ms">
                        <h2>Based High Technology</h2>
                        <P>Ut officia cupidatat anim excepteur fugiat cillum ea occaecat rump pork chop tempor. Ut tenderloin veniam commodo. Shankle aliquip short ribs, chicken eiusmod exercitation shank landjaeger spare ribs corned beef.</P>
                    </div>
                </div>
            </div>
        </div>
    </section>
     <!--/#features-->

    <section id="clients">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="clients text-center wow fadeInUp" data-wow-duration="500ms" data-wow-delay="300ms">
                        <p><img src="<?php echo base_url('assets/images/bimbo-cartoon-small.png')?>" class="img-responsive" alt=""></p>
                        <h1 class="title">Our Company</h1>
                        <p>Bimbo -Bimbingan Belajar Online. <br> Join us, and find new Experience about Learning </p>
                    </div>
                    <div class="clients-logo wow fadeIn" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <!-- <div class="col-xs-3 col-sm-2">
                            <a href="#"><img src="<?php echo base_url('assets/images/pic/home/client1.png')?>" class="img-responsive" alt=""></a>
                        </div>
                        <div class="col-xs-3 col-sm-2">
                            <a href="#"><img src="<?php echo base_url('assets/images/pic/home/client2.png')?>" class="img-responsive" alt=""></a>
                        </div>
                         <div class="col-xs-3 col-sm-2">
                            <a href="#"><img src="<?php echo base_url('assets/images/pic/home/client3.png')?>" class="img-responsive" alt=""></a>
                        </div>
                         <div class="col-xs-3 col-sm-2">
                            <a href="#"><img src="<?php echo base_url('assets/images/pic/home/client4.png')?>" class="img-responsive" alt=""></a>
                        </div>
                         <div class="col-xs-3 col-sm-2">
                            <a href="#"><img src="<?php echo base_url('assets/images/pic/home/client5.png')?>" class="img-responsive" alt=""></a>
                        </div>
                         <div class="col-xs-3 col-sm-2">
                            <a href="#"><img src="<?php echo base_url('assets/images/pic/home/client6.png')?>" class="img-responsive" alt=""></a>
                        </div> -->
                    </div>
                </div>
            </div>
        </div>

    <!-- Go To Top Link -->
    <a href="#" id="back-to-top" title="Back to top">&uarr;</a>
    </section>
    <!-- END CONTENT -->

  	<!-- FOOTER HERE -->
	<?php $this->load->view('footer'); ?>
	<!-- END FOOTER BRO -->	

    <!-- script -->
	<script src="<?php echo base_url('assets/js/extra/jquery.js'); ?>" type="text/javascript" ></script>
	<script src="<?php echo base_url('assets/js/bootstrap/bootstrap.min.js'); ?>" type="text/javascript" ></script>
	<script src="<?php echo base_url('assets/js/extra/lightbox.min.js'); ?>" type="text/javascript" ></script>
	<script src="<?php echo base_url('assets/js/extra/wow.min.js'); ?>" type="text/javascript" ></script>
	<script src="<?php echo base_url('assets/js/extra/main.js'); ?>" type="text/javascript" ></script>
    <script src="<?php echo base_url('assets/js/top-btn.js'); ?>" type="text/javascript"></script>
<!-- END WRAP EM ALL -->

</body>
</html>