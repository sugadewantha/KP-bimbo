<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title><?php echo $title; ?></title>
  <meta charset="utf-8">
  <!-- Responsive Metatag -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <!-- icon  -->
  <link rel="shortcut icon" href="<?php echo base_url('assets/images/bimbo-icon.png'); ?>" type="image/x-icon">
  <!-- style -->
  <link href="<?php echo base_url('assets/css/bootstrap/bootstrap.min.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
  <link href="<?php echo base_url('assets/css/style.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
  <link href="<?php echo base_url('assets/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
  <link href="<?php echo base_url('assets/css/lightbox.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
  <link href="<?php echo base_url('assets/css/responsive.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
  <link href="<?php echo base_url('assets/css/animate.min.css'); ?>" rel="stylesheet" type="text/css" >
  <link href="<?php echo base_url('assets/css/prettyPhoto.css'); ?>" rel="stylesheet" type="text/css" >
  <link href="<?php echo base_url('assets/css/uikit/uikit.css'); ?>" rel="stylesheet" type="text/css" >

</head>
<body>
<!-- WRAP EM ALL -->

  <!-- HEADER HERE -->
  <?php $this->load->view('header'); ?>
  <!-- END HEADER BRO --> 

    <section id="page-breadcrumb">
        <div class="vertical-center sun">
             <div class="container">
                <div class="row">
                    <div class="action">
                        <div class="col-sm-12">
                            <h1 class="title">Contact US</h1>
                            <p>Stay close</p>
                        </div>                        
                    </div>
                </div>
            </div>
        </div>
   </section>
    <!--/#action-->

    <section id="map-section">
        <div class="container">
            <div id="gmap"></div>
            <div class="contact-info">
                <h2>Contacts</h2>
                <address>
                E-mail: <a href="mailto:someone@example.com">bimbo@email.com</a> <br> 
                Phone: +62 (22) 456 7890 <br> 
                Fax: +62 (22) 456 7891 <br> 
                </address>

                <h2>Address</h2>
                <address>
                Jl. Sukajadi <br> 
                Kec Sukasari, <br> 
                Bandung, <br> 
                Indonesia <br> 
                </address>
            </div>
        </div>
    <!--/#map-section-->   

    <!-- Go To Top Link -->
    <a href="#" id="back-to-top" title="Back to top">&uarr;</a>
    </section>
    <!-- END CONTENT -->

    <!-- FOOTER HERE -->
    <?php $this->load->view('footer'); ?>
    <!-- END FOOTER BRO --> 

    <!-- script -->
  <script src="<?php echo base_url('assets/js/extra/jquery.js'); ?>" type="text/javascript"></script>
  <script src="<?php echo base_url('assets/js/bootstrap/bootstrap.min.js'); ?>" type="text/javascript"></script>
  <script src="<?php echo base_url('assets/js/extra/lightbox.min.js'); ?>" type="text/javascript"></script>
  <script src="<?php echo base_url('assets/js/extra/wow.min.js'); ?>" type="text/javascript"></script>
  <script src="<?php echo base_url('assets/js/extra/gmaps.js'); ?>" type="text/javascript"></script>
  <script src="http://maps.google.com/maps/api/js?sensor=true" type="text/javascript"></script>
  <script src="<?php echo base_url('assets/js/top-btn.js'); ?>" type="text/javascript"></script>
  <script src="<?php echo base_url('assets/js/map-custom.js'); ?>" type="text/javascript"></script>
  <script src="<?php echo base_url('assets/js/extra/main.js'); ?>" type="text/javascript"></script>
     
<!-- END WRAP EM ALL -->

</body>
</html>