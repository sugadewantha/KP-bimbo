<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $title; ?></title>
	<meta charset="utf-8">
	<!-- Responsive Metatag -->
 	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
 	<!-- icon  -->
	<link rel="shortcut icon" href="<?php echo base_url('assets/images/bimbo-icon.png'); ?>" type="image/x-icon">
	<!-- style -->
	<link href="<?php echo base_url('assets/css/bootstrap/bootstrap.min.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/main.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/responsive.css'); ?>" rel="stylesheet" type="text/css"  media="all" />

</head>
<body>
<!-- FOOTER -->
	
    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-center bottom-separator">
                    <img src="<?php echo base_url('assets/images/pic/home/under.png')?>" class="img-responsive inline" alt="">
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="testimonial bottom">
                        <h2>Testimonial</h2>
                        <div class="media">
                            <div class="pull-left">
                                <a href="#"><img src="<?php echo base_url('assets/images/pic/home/profile1.png')?>" alt=""></a>
                            </div>
                            <div class="media-body">
                                <blockquote>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</blockquote>
                                <h3><a href="#">- Rainata Triyadi</a></h3>
                            </div>
                         </div>
                        <div class="media">
                            <div class="pull-left">
                                <a href="#"><img src="<?php echo base_url('assets/images/pic/home/profile2.png')?>" alt=""></a>
                            </div>
                            <div class="media-body">
                                <blockquote>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris 
                                nisi ut aliquip ex ea commodo consequat. </blockquote>
                                <h3><a href="">- Erwins Wiradhika</a></h3>
                            </div>
                        </div>   
                    </div> 
                </div>
                <div class="col-md-4 col-sm-12">
                    <div class="contact-form bottom">
                        <h2>Contacts</h2>
                        <address>
                        E-mail: <a href="mailto:someone@example.com">Bimbo@email.com</a> <br> 
                        Phone: +62 (22) 456 7890 <br> 
                        Fax: +62 (22) 456 7891 <br> 
                        </address>

                        <h2>Address</h2>
                        <address>
                        Jl. Sukajadi <br> 
                        Kec Sukasari, <br> 
                        Bandung, <br> 
                        Indonesia <br> 
                        </address>
                    </div>
                </div>
                <!-- <div class="col-md-4 col-sm-12">
                    <div class="contact-form bottom">
                        <h2>Send a message</h2>
                        <form id="main-contact-form" name="contact-form" method="post" action="sendemail.php">
                            <div class="form-group">
                                <input type="text" name="name" class="form-control" required="required" placeholder="Name">
                            </div>
                            <div class="form-group">
                                <input type="email" name="email" class="form-control" required="required" placeholder="Email Id">
                            </div>
                            <div class="form-group">
                                <textarea name="message" id="message" required="required" class="form-control" rows="8" placeholder="Your text here"></textarea>
                            </div>                        
                            <div class="form-group">
                                <input type="submit" name="submit" class="btn btn-submit" value="Submit">
                            </div>
                        </form>
                    </div>
                </div> -->
                <div class="col-sm-12">
                    <div class="copyright-text text-center">
                        <p>&copy; Bimbo 2016. All Rights Reserved.</p>
                        <p>Designed by <!-- <a target="_blank" href="http://www.themeum.com"> -->RSDG</a></p>
                        <p>Powered by <!-- <a target="_blank" href="http://www.themeum.com"> -->Themeum</a></p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!--/#footer-->
<!--END FOOTER BRO-->
</body>
</html>