<div class="container main">   
  	<div class="page-header">
  		<h1>Editor Page</h1>
  	</div>
	
	  <div class="well">			
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nemo repudiandae quis fugiat numquam eveniet voluptate ullam cupiditate earum officiis, modi, repellendus vero animi et. Porro corporis inventore ducimus voluptates necessitatibus.</p>
		</div>
  </div>