<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $title; ?></title>
	<meta charset="utf-8">
	<!-- Responsive Metatag -->
 	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
 	<!-- icon  -->
	<link rel="shortcut icon" href="<?php echo base_url('assets/images/bimbo-icon.png'); ?>" type="image/x-icon">
	<!-- style -->
	<link href="<?php echo base_url('assets/css/bootstrap/bootstrap.min.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/style.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/lightbox.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/responsive.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/animate.min.css'); ?>" rel="stylesheet" type="text/css" >
	<link href="<?php echo base_url('assets/css/uikit/uikit.css'); ?>" rel="stylesheet" type="text/css" >

</head>
<body>
<!-- WRAP EM ALL -->

	<!-- HEADER HERE -->
	<?php $this->load->view('header'); ?>
	<!-- END HEADER BRO -->	

    <section id="page-breadcrumb">
        <div class="vertical-center sun">
             <div class="container">
                <div class="row">
                    <div class="action">
                        <div class="col-sm-12">
                            <h1 class="title">About Us</h1>
                            <p>About Bimbo Company</p>
                        </div>
                     </div>
                </div>
            </div>
        </div>
   </section>
    <!--/#page-breadcrumb-->

    <section id="about-company" class="padding-top wow fadeInUp" data-wow-duration="400ms" data-wow-delay="400ms">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 text-center">
                    <img src="<?php echo base_url('assets/images/bimbo-cartoon-small.png')?>" class="margin-bottom" alt="">
                    <h1 class="margin-bottom">About Our Company</h1>
                    <p>Pork chop duis eu pig, labore sausage venison. Shankle fugiat duis, filet mignon tri-tip venison beef shank ribeye<br /> aliqua cillum dolore sed do in.</p>
                </div>
            </div>
        </div>
    </section>
    <!--/#about-company-->
    
    <section id="services">
        <div class="container">
            <div class="row">
                <div class="col-sm-4 text-center padding wow fadeIn" data-wow-duration="1000ms" data-wow-delay="300ms">
                    <div class="single-service">
                        <div class="wow scaleIn" data-wow-duration="500ms" data-wow-delay="300ms">
                            <img src="<?php echo base_url('assets/images/pic/home/icon1.png')?>" alt="">
                        </div>
                        <h2>Smart Education</h2>
                        <p>Ground round tenderloin flank shank ribeye. Hamkevin meatball swine. Cow shankle beef sirloin chicken ground round.</p>
                    </div>
                </div>
                <div class="col-sm-4 text-center padding wow fadeIn" data-wow-duration="1000ms" data-wow-delay="600ms">
                    <div class="single-service">
                        <div class="wow scaleIn" data-wow-duration="500ms" data-wow-delay="600ms">
                            <img src="<?php echo base_url('assets/images/pic/home/icon2.png')?>" alt="">
                        </div>
                        <h2>Based High Technology</h2>
                        <p>Hamburger ribeye drumstick turkey, strip steak sausage ground round shank pastrami beef brisket pancetta venison.</p>
                    </div>
                </div>
                <div class="col-sm-4 text-center padding wow fadeIn" data-wow-duration="1000ms" data-wow-delay="900ms">
                    <div class="single-service">
                        <div class="wow scaleIn" data-wow-duration="500ms" data-wow-delay="900ms">
                            <img src="<?php echo base_url('assets/images/pic/home/icon3.png')?>" alt="">
                        </div>
                        <h2>Practice Learning</h2>
                        <p>Venison tongue, salami corned beef ball tip meatloaf bacon. Fatback pork belly bresaola tenderloin bone pork kevin shankle.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!--/#action-->

    <section id="company-information" class="padding-top">
        <div class="container">
            <div class="row">
                <div class="about-us">
                    <div class="col-sm-7 wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="300ms">
                        <h2 class="bold">About Bimbo</h2>
                        <div class="row">
                            <div class="col-sm-5">
                                <img src="<?php echo base_url('assets/images/bimbo-logo-cartoon.png')?>" class="img-responsive" alt="">
                            </div>
                            <div class="col-sm-7">
                                <h3 class="top-zero">Who we are</h3>
                                <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. <br> <br> Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-5 wow fadeInRight" data-wow-duration="1000ms" data-wow-delay="300ms">
                        <div class="our-skills">
                            <h2 class="bold">Our Skills</h2>
                            <div class="single-skill">
                                <h3>Design</h3>
                                <div class="progress">
                                    <div class="progress-bar progress-bar-primary six-sec-ease-in-out" role="progressbar"  data-transition="35">35%</div>
                                </div>
                            </div>
                            <div class="single-skill">
                                <h3>Website</h3>
                                <div class="progress">
                                    <div class="progress-bar progress-bar-primary six-sec-ease-in-out" role="progressbar"  data-transition="80">80%</div>
                                </div>
                            </div>
                            <div class="single-skill">
                                <h3>Desktop</h3>
                                <div class="progress">
                                    <div class="progress-bar progress-bar-primary six-sec-ease-in-out" role="progressbar"  data-transition="60">60%</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--/#company-information-->

    <!-- Go To Top Link -->
    <a href="#" id="back-to-top" title="Back to top">&uarr;</a>
    </section>
    <!-- END CONTENT -->

    <!-- FOOTER HERE -->
	<?php $this->load->view('footer'); ?>
	<!-- END FOOTER BRO -->	

    <!-- script -->
	<script src="<?php echo base_url('assets/js/extra/jquery.js'); ?>" type="text/javascript" ></script>
	<script src="<?php echo base_url('assets/js/bootstrap/bootstrap.min.js'); ?>" type="text/javascript" ></script>
	<script src="<?php echo base_url('assets/js/extra/lightbox.min.js'); ?>" type="text/javascript" ></script>
	<script src="<?php echo base_url('assets/js/extra/wow.min.js'); ?>" type="text/javascript" ></script>
    <script src="<?php echo base_url('assets/js/extra/jquery.countTo.js'); ?>" type="text/javascript" ></script>
	<script src="<?php echo base_url('assets/js/extra/main.js'); ?>" type="text/javascript" ></script>
    <script src="<?php echo base_url('assets/js/top-btn.js'); ?>" type="text/javascript"></script>
    <!-- END WRAP EM ALL -->

</body>
</html>