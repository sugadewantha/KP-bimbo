<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $title; ?></title>
	<meta charset="utf-8">
	<!-- Responsive Metatag -->
 	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
 	<!-- icon  -->
	<link rel="shortcut icon" href="<?php echo base_url('assets/images/bimbo-icon.png'); ?>" type="image/x-icon">
	<link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo base_url('assets/images/pic/ico/apple-touch-icon-144-precomposed.png'); ?>">
	<link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo base_url('assets/images/pic/ico/apple-touch-icon-114-precomposed.png'); ?>">
	<link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo base_url('assets/images/pic/ico/apple-touch-icon-72-precomposed.png'); ?>">
	<link rel="apple-touch-icon-precomposed" href="<?php echo base_url('assets/images/pic/ico/apple-touch-icon-57-precomposed.png'); ?>">
	
	<!-- style -->
	<link href="<?php echo base_url('assets/css/bootstrap/bootstrap.min.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/style.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
	<link href="<?php echo base_url('assets/css/responsive.css'); ?>" rel="stylesheet" type="text/css"  media="all" />


</head>
<body>
<!-- HEADER HERE -->
	<header id="header">      
        <div class="container">
            <div class="row">
                <div class="col-sm-12 overflow">
                   <div class="social-icons pull-right">
                        <ul class="nav nav-pills">
                           <!--  <li><a data-toggle="modal" data-target="#modal-login"><span class="fa fa-power-off" aria-hidden="true"></span></a></li> -->
                        </ul>
                    </div> 
                </div>
             </div>
        </div>
        <div class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>

                    <a class="navbar-brand" href="index.html">
                    	<h1><img src="<?php echo base_url('assets/images/bimbo-logo-top.png')?>" alt="logo"></h1>
                    </a>
                    
                </div>
                <div class="collapse navbar-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="<?php echo base_url()."index.php/masterController/home"; ?>">Home</a></li>
                        <li><a href="<?php echo base_url()."index.php/masterController/activity"; ?>">Activity <!-- <i class="fa fa-angle-down"></i> --></a>
                            <!-- <ul role="menu" class="sub-menu">
                                <li><a href="aboutus.html">About</a></li>
                                <li><a href="aboutus2.html">About 2</a></li>
                            </ul> -->
                        </li>                    
                        <li><a href="<?php echo base_url()."index.php/masterController/gallery"; ?>">Gallery</a></li> 
                        <li><a href="<?php echo base_url()."index.php/masterController/about"; ?>">About</a></li>                       
                        <li><a href="<?php echo base_url()."index.php/masterController/contact"; ?>">Contact</a></li>                    
                    </ul>
                </div>
                <div class="search">
                    <form role="form">
                        <i class="fa fa-search"></i>
                        <div class="field-toggle">
                            <input type="text" class="search-form" autocomplete="off" placeholder="Search">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </header>
    <!--END HEADER BRO-->

    <!-- MODAL -->
        <div class="modal fade" id="modal-login" tabindex="-1" role="dialog" aria-labelledby="modal-login-label" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    
                   <!--  <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">
                            <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
                        </button>
                        <h3 class="modal-title" id="modal-login-label">Login to our site</h3>
                        <p>Enter your username and password to log on:</p>
                    </div> -->
                    
                    <div class="modal-body">
                        
                        <form role="form" action="" method="post" class="login-form">
                                    
                                   <h1><img src="<?php echo base_url('assets/images/bimbo-logo-cartoon.png')?>" alt="logo"></h1>
                                     <div class="form-group ">
                                       <input type="text" class="form-control" placeholder="Username " id="UserName">
                                       <i class="fa fa-user"></i>
                                     </div>
                                     <div class="form-group log-status">
                                       <input type="password" class="form-control" placeholder="Password" id="Passwod">
                                       <i class="fa fa-lock"></i>
                                     </div>
                                    <span class="alert">Invalid Credentials</span>
                                    <a class="link" href="#">Lost your password?</a>
                                    <button type="button" class="log-btn" >Log in</button>
                                     <li><a href="<?php echo base_url()."index.php/adminController/dashboard"; ?>">Login here</a></li> 
                                    <h2>"Login Just for Admin!"</h2>
                                </div>
                              </div>
                        </form>
                        
                    </div>
                    
                </div>
            </div>
        </div>

    <!-- START LOGIN MODAL -->
    <!-- <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">

          <div class="modal-body">
            <div class="login-form">
               <h1>Vini</h1>
                 <div class="form-group ">
                   <input type="text" class="form-control" placeholder="Username " id="UserName">
                   <i class="fa fa-user"></i>
                 </div>
                 <div class="form-group log-status">
                   <input type="password" class="form-control" placeholder="Password" id="Passwod">
                   <i class="fa fa-lock"></i>
                 </div>
                <span class="alert">Invalid Credentials</span>
                <a class="link" href="#">Lost your password?</a>
                <button type="button" class="log-btn" >Log in</button>
            </div>
          </div>
        </div>
      </div>
    </div> -->
    <!-- END MODAL BRO -->

	<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="<?php echo base_url('assets/js/ie10-viewport-bug-workaround.js'); ?>" type="text/javascript" ></script>
    <script src="<?php echo base_url('assets/js/bootstrap/bootstrap.min.js'); ?>" type="text/javascript" ></script>
    <script src="<?php echo base_url('assets/js/extra/jquery.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/js/jquery.backstretch.min.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/js/login-modal.js'); ?>" type="text/javascript"></script>
    <script src="<?php echo base_url('assets/js/login-custom.js'); ?>" type="text/javascript"></script>

</body>
</html>
