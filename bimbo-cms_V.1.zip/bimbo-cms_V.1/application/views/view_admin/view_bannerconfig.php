<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title><?php echo $title; ?></title>
  <meta charset="utf-8">
  <!-- Responsive Metatag -->
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <!-- icon  -->
  <link rel="shortcut icon" href="<?php echo base_url('assets/images/bimbo-icon.png'); ?>" type="image/x-icon">
  <!-- style -->
  <link href="<?php echo base_url('assets/css/bootstrap/bootstrap.min.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
  <link href="<?php echo base_url('assets/css/bootstrap/bootstrap.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
  <link href="<?php echo base_url('assets/css/font-awesome.min.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
  <link href="<?php echo base_url('assets/css/lineicons/style.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
  <link href="<?php echo base_url('assets/css/lightbox.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
  <link href="<?php echo base_url('assets/css/responsive.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
  <!-- custom style -->
  <link href="<?php echo base_url('assets/css/adminstyle.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
  <link href="<?php echo base_url('assets/css/style-responsive.css'); ?>" rel="stylesheet" type="text/css"  media="all" />
  </head>
<body>
<!-- WRAP EM ALL -->
   
  <section id="container" >
      
      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
                  <p class="centered"><a href="profile.html"><img src="<?php echo base_url('assets/images/users/author.png')?>" class="img-circle" width="60"></a></p>
                  <h5 class="centered">Sugadewantha</h5>
                    
                  <li class="mt">
                      <a href="<?php echo base_url()."index.php/adminController/dashboard"; ?>">
                          <i class="fa fa-dashboard"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>

                  <li class="sub-menu">
                      <a href="javascript:;" >
                          <i class="fa fa-desktop"></i>
                          <span>Additional Pages</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="<?php echo base_url()."index.php/adminController/calendarPage"; ?>">Calendar</a></li>
                          <li><a  href="<?php echo base_url()."index.php/adminController/adminGallery"; ?>">Gallery</a></li>
                          <li><a  href="todo_list.html">Todo List</a></li>
                      </ul>
                  </li>

                  <li class="sub-menu">
                      <a class="active" href="javascript:;" >
                          <i class="fa fa-cogs"></i>
                          <span>Page Configuration</span>
                      </a>
                      <ul class="sub">
                          <li><a  href="<?php echo base_url()."index.php/adminController/bannerConfig"; ?>">Banner Edit</a></li>
                      </ul>
                  </li>
              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->

      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
      <section id="main-content">
          <section class="wrapper site-min-height">
            <h3><i class="fa fa-angle-right"></i>Banner Configuration</h3>
            <div class="row mt">
              <div class="col-lg-12">



              <!-- ============1=============  -->
              <ol id="qunit-tests"></ol>
              <div id="qunit-fixture">
                  <!-- The file upload form used as target for the file upload widget -->
                   <form id="fileupload" action="<?php echo base_url('assets/server/php/index.php'); ?>" method="POST" enctype="multipart/form-data">
                      <!-- The fileupload-buttonbar contains buttons to add/delete files and start/cancel the upload -->
                     <div class="row fileupload-buttonbar">
                          <div class="col-lg-7">
                              <!-- The fileinput-button span is used to style the file input field as button -->
                              <span class="btn btn-success fileinput-button">
                                  <i class="icon-plus icon-white"></i>
                                  <span>Add files...</span>
                                  <input type="file" name="files[]" multiple>
                              </span>
                              <button type="submit" class="btn btn-primary start">
                                  <i class="icon-upload icon-white"></i>
                                  <span>Start upload</span>
                              </button>
                              <button type="reset" class="btn btn-warning cancel">
                                  <i class="icon-ban-circle icon-white"></i>
                                  <span>Cancel upload</span>
                              </button>
                              <button type="button" class="btn btn-danger delete">
                                  <i class="icon-trash icon-white"></i>
                                  <span>Delete</span>
                              </button>
                              <input type="checkbox" class="toggle">
                              <!-- The global file processing state -->
                              <span class="fileupload-process"></span>
                          </div>
                          <!-- The global progress state -->
                          <div class="col-lg-5 fileupload-progress">
                              <!-- The global progress bar -->
                              <div class="progress progress-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100">
                                  <div class="progress-bar progress-bar-success" style="width:0%;"></div>
                              </div>
                              <!-- The extended global progress state -->
                              <div class="progress-extended">&nbsp;</div>
                          </div>
                      </div>
                      <!-- The table listing the files available for upload/download -->
                       <table role="presentation" class="table table-striped"><tbody class="files"></tbody></table>
                  </form>
              </div>

              <!-- ============2=============  -->
               <!--START HOME SLIDER -->
                <!-- <section id="home">
           
                  <div id="main-slide" class="carousel slide bnr-post" data-ride="carousel">

                    <ol class="carousel-indicators">
                      <li data-target="#main-slide" data-slide-to="0" class="active"></li>
                      <li data-target="#main-slide" data-slide-to="1"></li>
                      <li data-target="#main-slide" data-slide-to="2"></li>
                    </ol>

                    <div class="carousel-inner">
                      <div class="item active">
                        <img class="img-responsive" src="<?php echo base_url('assets/images/slider/banner-1.png')?>" alt="slider">
                        <div class="slider-content">
                          <div class="col-md-12 text-center">
                            <h2 class="animated2">
                              <span>Welcome to <strong>BIMBO</strong></span>
                          </h2>
                            <h3 class="animated3">
                           <span>Bimbingan Belajar Online Terpadu</span>
                       </h3>
                            
                          </div>
                        </div>
                      </div>
                    
                      <div class="item">
                        <img class="img-responsive" src="<?php echo base_url('assets/images/slider/banner-2.png')?>" alt="slider">
                        <div class="slider-content">
                          <div class="col-md-12 text-center">
                            <h2 class="animated4">
                           
                        </h2>
                            <h3 class="animated5">
                      
                       </h3>
                           
                          </div>
                        </div>
                      </div>
                     
                      <div class="item">
                        <img class="img-responsive" src="<?php echo base_url('assets/images/slider/banner-3.png')?>" alt="slider">
                        <div class="slider-content">
                          <div class="col-md-12 text-center">
                            <h2 class="animated7 white">
                            <span>The way of <strong>Success</strong></span>
                        </h2>
                            <h3 class="animated8 white">
                           <span>Why you are waiting</span>
                       </h3>
                            <div class="">
                            
                            </div>
                          </div>
                        </div>
                      </div>
                   
                    </div>
                    

                  
                    <a class="left carousel-control" href="#main-slide" data-slide="prev">
                      <span><i class="fa fa-angle-left"></i></span>
                    </a>
                    <a class="right carousel-control" href="#main-slide" data-slide="next">
                      <span><i class="fa fa-angle-right"></i></span>
                    </a>
                  </div>
                
                </section>

              </div>
            </div>
           </section> <!-- end wrapper -->
        </section> --><!-- end MAIN CONTENT -->

        <!--main content end-->
        <!--footer start-->
        <footer class="site-footer">
            <div class="text-center">
                2014 - Alvarez.is
                <a href="blank.html#" class="go-top">
                    <i class="fa fa-angle-up"></i>
                </a>
            </div>
        </footer>
        <!--footer end-->

    </section>
<!-- END WRAP EM ALL -->
      <!-- The template to display files available for upload -->
    <script id="template-upload" type="text/x-tmpl">
    {% for (var i=0, file; file=o.files[i]; i++) { %}
        <tr class="template-upload">
            <td>
                <span class="preview"></span>
            </td>
            <td>
                <p class="name">{%=file.name%}</p>
                <strong class="error text-danger"></strong>
            </td>
            <td>
                <p class="size">Processing...</p>
                <div class="progress progress-striped active" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div class="progress-bar progress-bar-success" style="width:0%;"></div></div>
            </td>
            <td>
                {% if (!i && !o.options.autoUpload) { %}
                    <button class="btn btn-primary start" disabled>
                        <i class="glyphicon glyphicon-upload"></i>
                        <span>Start</span>
                    </button>
                {% } %}
                {% if (!i) { %}
                    <button class="btn btn-warning cancel">
                        <i class="glyphicon glyphicon-ban-circle"></i>
                        <span>Cancel</span>
                    </button>
                {% } %}
            </td>
        </tr>
    {% } %}
    </script>
    <!-- The template to display files available for download -->
    <script id="template-download" type="text/x-tmpl">
    {% for (var i=0, file; file=o.files[i]; i++) { %}
        <tr class="template-download">
            <td>
                <span class="preview">
                    {% if (file.thumbnailUrl) { %}
                        <a href="{%=file.url%}" title="{%=file.name%}" download="{%=file.name%}" data-gallery><img src="{%=file.thumbnailUrl%}"></a>
                    {% } %}
                </span>
            </td>
            <td>
                <p class="name">
                    {% if (file.url) { %}
                        <a href="{%=file.url%}" title="{%=file.name%}" download="{%=file.name%}" {%=file.thumbnailUrl?'data-gallery':''%}>{%=file.name%}</a>
                    {% } else { %}
                        <span>{%=file.name%}</span>
                    {% } %}
                </p>
                {% if (file.error) { %}
                    <div><span class="label label-danger">Error</span> {%=file.error%}</div>
                {% } %}
            </td>
            <td>
                <span class="size">{%=o.formatFileSize(file.size)%}</span>
            </td>
            <td>
                {% if (file.deleteUrl) { %}
                    <button class="btn btn-danger delete" data-type="{%=file.deleteType%}" data-url="{%=file.deleteUrl%}"{% if (file.deleteWithCredentials) { %} data-xhr-fields='{"withCredentials":true}'{% } %}>
                        <i class="glyphicon glyphicon-trash"></i>
                        <span>Delete</span>
                    </button>
                    <input type="checkbox" name="delete" value="1" class="toggle">
                {% } else { %}
                    <button class="btn btn-warning cancel">
                        <i class="glyphicon glyphicon-ban-circle"></i>
                        <span>Cancel</span>
                    </button>
                {% } %}
            </td>
        </tr>
    {% } %}
    </script>

  <!--theme script -->
  <script src="<?php echo base_url('assets/js/extra/jquery.js'); ?>" type="text/javascript" ></script>
  <script src="<?php echo base_url('assets/js/jquery.min.js'); ?>" type="text/javascript" ></script>
  <script src="<?php echo base_url('assets/js/bootstrap/bootstrap.min.js'); ?>" type="text/javascript" ></script>
  <script src="<?php echo base_url('assets/js/jquery.dcjqaccordion.2.7.js'); ?>" type="text/javascript" ></script>
  <script src="<?php echo base_url('assets/js/extra/lightbox.min.js'); ?>" type="text/javascript" ></script>
  <script src="<?php echo base_url('assets/js/jquery.scrollTo.min.js'); ?>" type="text/javascript" ></script>
  <script src="<?php echo base_url('assets/js/jquery.nicescroll.js'); ?>" type="text/javascript" ></script>
  <script src="<?php echo base_url('assets/js/slider.js'); ?>" type="text/javascript" ></script>

  <!--Upload file script -->
  <script src="<?php echo base_url('assets/js/fileupload/jquery.ui.widget.js'); ?>" type="text/javascript" ></script>
  <script src="<?php echo base_url('assets/js/fileupload/jquery.iframe-transport.js'); ?>" type="text/javascript" ></script>
  <script src="<?php echo base_url('assets/js/fileupload/jquery.fileupload.js'); ?>" type="text/javascript" ></script>
  <script>
  /* global window, $ */
  window.testBasicWidget = $.blueimp.fileupload;
  </script>
  <script src="<?php echo base_url('assets/js/fileupload/jquery.fileupload-process.js'); ?>" type="text/javascript" ></script>
  <script src="<?php echo base_url('assets/js/fileupload/jquery.fileupload-image.js'); ?>" type="text/javascript" ></script>
  <script src="<?php echo base_url('assets/js/fileupload/jquery.fileupload-validate.js'); ?>" type="text/javascript" ></script>
  <script src="<?php echo base_url('assets/js/fileupload/jquery.fileupload-ui.js'); ?>" type="text/javascript" ></script>
  <script src="<?php echo base_url('assets/js/fileupload/qunit-1.15.0.js'); ?>" type="text/javascript" ></script>
  <script>
  /* global window, $ */
  window.testUIWidget = $.blueimp.fileupload;
  </script>

  <!-- common script all admin pages -->
  <script src="<?php echo base_url('assets/js/common-scripts.js'); ?>" type="text/javascript" ></script>
  <script>
      //custom select box

      $(function(){
          $('select.styled').customSelect();
      });

  </script>

</body>
</html>