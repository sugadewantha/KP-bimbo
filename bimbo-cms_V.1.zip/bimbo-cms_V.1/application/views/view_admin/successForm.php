<html>
<head>
<title>Upload Form</title>
</head>
<body>

<h3>Your file was successfully uploaded!</h3>

<ul>
<?php foreach ($upload_data as $item => $value):?>
<li><?php echo $item;?>: <?php echo $value;?></li>
<?php endforeach; ?>
</ul>

<?php foreach($userfile as $c){ ?>
        

            
              

               
               <tr>
                     
               <td> <userfile width="300" height="240" controls>
  					<source src="<?php echo base_url($c['userfile']); ?>" type="jpg/png/gif">
					</userfile> </td>
              <br>
              <td> <H3><?php echo ($c['Title']); ?></H3>  </td>
              <br>
               </tr>

              <?php } ?>


<p><?php echo anchor('upload', 'Upload Another File!'); ?></p>

</body>
</html>